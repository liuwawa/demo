package com.huawei.android.hms.agent.push.handler;

import com.huawei.android.hms.agent.common.handler.ICallbackCode;

/**
 * 获取 pushtoken 回调
 */
public interface GetTokenHandler extends ICallbackCode {
}
