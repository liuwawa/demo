package com.huawei.android.hms.agent.push.handler;

import com.huawei.android.hms.agent.common.handler.ICallbackCode;

/**
 * queryAgreement 回调
 */
public interface QueryAgreementHandler extends ICallbackCode {
}
