package com.tencent.qcloud.tim.uikit.modules.message;

public class MessageTyping {

    public static final int TYPE_TYPING = 14;
    public static final String EDIT_START = "EIMAMSG_InputStatus_Ing";
    public static final String EDIT_END = "EIMAMSG_InputStatus_End";

    public int userAction = 0;
    public String actionParam = "";

}
