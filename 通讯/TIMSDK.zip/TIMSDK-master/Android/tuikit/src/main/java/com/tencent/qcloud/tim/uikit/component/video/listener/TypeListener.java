package com.tencent.qcloud.tim.uikit.component.video.listener;

public interface TypeListener {
    void cancel();

    void confirm();
}
