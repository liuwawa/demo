package com.tencent.qcloud.tim.uikit.utils;

import android.support.v4.content.FileProvider;

public class TUIKitFileProvider extends FileProvider {
}
