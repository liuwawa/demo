package com.tencent.qcloud.tim.uikit.component.video.listener;

public interface ErrorListener {

    void onError();

    void AudioPermissionError();
}
