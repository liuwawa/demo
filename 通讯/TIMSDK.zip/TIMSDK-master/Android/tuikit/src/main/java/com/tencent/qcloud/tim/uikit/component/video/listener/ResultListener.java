package com.tencent.qcloud.tim.uikit.component.video.listener;

public interface ResultListener {
    void callback();
}
