package com.tencent.qcloud.tim.uikit.modules.conversation.base;

import com.tencent.qcloud.tim.uikit.component.gatherimage.DynamicLayoutView;

public abstract class DynamicConversationIconView extends DynamicLayoutView<ConversationInfo> {

}
