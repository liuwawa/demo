# TIM SDK（Android）

## 下载地址

[最新TUIKit aar 和IM SDK aar下载](https://imsdk-1252463788.cos.ap-guangzhou.myqcloud.com/4.6.56/TIM_SDK_Android_latest_aar.zip)

